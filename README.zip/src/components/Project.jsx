import React from 'react';

const Projects = () => {
  return (
    <section id="projects" className="py-20 px-6 bg-white text-center">
      <h2 className="text-3xl font-bold mb-8">Projects</h2>
      <div className="grid md:grid-cols-2 gap-10">
        <div className="bg-gray-100 p-6 rounded shadow">
          <h3 className="text-xl font-semibold mb-2">Amazon Clone</h3>
          <p className="mb-4">Built with React, Bootstrap, Java Spring Boot, Hibernate, MySQL.</p>
          <a href="https://github.com/yourgithub/amazon-clone" className="text-blue-600">GitHub Link</a>
        </div>

        <div className="bg-gray-100 p-6 rounded shadow">
          <h3 className="text-xl font-semibold mb-2">Hospital Management System</h3>
          <p className="mb-4">Spring Boot + React based HMS system with patient and admin modules.</p>
          <a href="https://github.com/yourgithub/hospital-system" className="text-blue-600">GitHub Link</a>
        </div>
      </div>
    </section>
  );
};

export default Projects;