import React from 'react';

const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-gray-100 text-center">
      <h2 className="text-3xl font-bold mb-4">Skills</h2>
      <div className="flex flex-wrap justify-center gap-6 mt-8">
        <span className="bg-white px-4 py-2 rounded shadow">HTML</span>
        <span className="bg-white px-4 py-2 rounded shadow">CSS</span>
        <span className="bg-white px-4 py-2 rounded shadow">JavaScript</span>
        <span className="bg-white px-4 py-2 rounded shadow">React</span>
        <span className="bg-white px-4 py-2 rounded shadow">Java</span>
        <span className="bg-white px-4 py-2 rounded shadow">Spring Boot</span>
        <span className="bg-white px-4 py-2 rounded shadow">MySQL</span>
        <span className="bg-white px-4 py-2 rounded shadow">GitHub</span>
      </div>
    </section>
  );
};

export default Skills;