import React from 'react';

const Contact = () => {
  return (
    <section id="contact" className="py-20 px-6 bg-gray-100 text-center">
      <h2 className="text-3xl font-bold mb-6">Contact Me</h2>
      <p className="mb-4">Email: gyanendra.mishra@example.com</p>
      <p>LinkedIn: <a href="https://linkedin.com/in/gyanendra" className="text-blue-600">Visit Profile</a></p>
    </section>
  );
};

export default Contact;