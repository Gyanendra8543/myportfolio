import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 px-6 bg-white text-center">
      <h2 className="text-3xl font-bold mb-4">About Me</h2>
      <p className="text-gray-700 max-w-2xl mx-auto">
        I am a passionate Java Full Stack Developer with experience in building scalable web apps using Java, Spring Boot, React, and MySQL. I love creating clean and user-friendly interfaces.
      </p>
    </section>
  );
};

export default About;