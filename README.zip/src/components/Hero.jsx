import React from 'react';

const Hero = () => {
  return (
    <section id="home" className="pt-32 text-center bg-gray-100 min-h-screen">
      <h1 className="text-4xl font-bold mb-4">Hi, I'm Gyanendra Mishra</h1>
      <p className="text-xl text-gray-700 mb-6">Java Full Stack Developer | React Enthusiast</p>
      <a href="#projects" className="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700 transition">See My Work</a>
      <h1 className="text-5xl text-green-600 font-bold text-center mt-10">
  ✅ Hello Mishra Ji, Tailwind is Finally Working!
</h1>
    </section>
  );
};

export default Hero;